composer archive create -t dir -n .


